import type { ReactNode } from "react";
import DashboardShell from "@/components/DashboardShell";

export default function SettingsLayout({ children }: { children: ReactNode }) {
    return <DashboardShell>{children}</DashboardShell>;
}
